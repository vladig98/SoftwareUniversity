﻿namespace BWCommandStrikeBack.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
