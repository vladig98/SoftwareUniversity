﻿namespace BWCommandStrikeBack.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
