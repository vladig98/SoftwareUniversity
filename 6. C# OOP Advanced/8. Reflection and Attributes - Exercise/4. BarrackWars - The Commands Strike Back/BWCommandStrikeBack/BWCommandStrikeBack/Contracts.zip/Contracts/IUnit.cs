﻿namespace BWCommandStrikeBack.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {
    }
}
