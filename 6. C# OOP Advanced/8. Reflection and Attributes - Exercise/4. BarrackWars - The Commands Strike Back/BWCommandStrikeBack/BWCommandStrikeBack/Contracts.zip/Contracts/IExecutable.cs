﻿namespace BWCommandStrikeBack.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
