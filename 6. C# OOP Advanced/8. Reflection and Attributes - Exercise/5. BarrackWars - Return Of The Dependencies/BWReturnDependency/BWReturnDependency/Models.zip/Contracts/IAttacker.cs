﻿namespace BWReturnDependency.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
