﻿namespace BWReturnDependency.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
