﻿namespace BWReturnDependency.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {
    }
}
