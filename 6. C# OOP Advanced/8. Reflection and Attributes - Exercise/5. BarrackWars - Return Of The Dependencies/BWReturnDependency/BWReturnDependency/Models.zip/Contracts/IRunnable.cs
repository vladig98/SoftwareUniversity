﻿namespace BWReturnDependency.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
