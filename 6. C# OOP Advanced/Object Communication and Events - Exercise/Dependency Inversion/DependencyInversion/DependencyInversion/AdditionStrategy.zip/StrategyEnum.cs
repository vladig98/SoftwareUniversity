﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DependencyInversion
{
    public enum StrategyEnum
    {
        ADDITION,
        SUBTRACTION,
        MULTIPLICATION,
        DIVISION
    }
}
