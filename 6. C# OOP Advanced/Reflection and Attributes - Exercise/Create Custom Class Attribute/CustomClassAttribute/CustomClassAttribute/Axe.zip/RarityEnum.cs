﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomClassAttribute
{
    public enum RarityEnum
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
