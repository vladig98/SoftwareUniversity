﻿namespace InfernoInfinityBonus.Models.Enums
{
    public enum GemEnum
    {
        Ruby,
        Emerald,
        Amethyst
    }
}
