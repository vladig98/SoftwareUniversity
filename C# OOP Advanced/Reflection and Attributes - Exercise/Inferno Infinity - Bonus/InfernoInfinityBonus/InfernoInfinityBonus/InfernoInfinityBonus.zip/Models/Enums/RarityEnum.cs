﻿namespace InfernoInfinityBonus.Models.Enums
{
    public enum RarityEnum
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
