﻿using System;

namespace InfernoInfinityBonus.Core.IO
{
    public static class InputReader
    {
        public static string ReadLineFromConsole()
        {
            return Console.ReadLine();
        }
    }
}
