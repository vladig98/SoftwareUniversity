﻿using System;

namespace InfernoInfinityBonus.Core.Commands
{
    [AttributeUsage(AttributeTargets.Field)]
    public class InjectAttribute : Attribute
    {
    }
}
