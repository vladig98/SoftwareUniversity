﻿namespace BarrackWarsANewFactory.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
