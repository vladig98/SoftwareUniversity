﻿namespace BarrackWarsANewFactory.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
