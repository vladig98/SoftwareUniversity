﻿namespace BarrackWarsANewFactory.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
