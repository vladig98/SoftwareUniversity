﻿namespace BarrackWarsANewFactory.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {
    }
}
