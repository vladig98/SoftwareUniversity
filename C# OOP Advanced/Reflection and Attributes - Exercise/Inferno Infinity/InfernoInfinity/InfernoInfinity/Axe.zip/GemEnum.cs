﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfernoInfinity
{
    public enum GemEnum
    {
        Ruby,
        Emerald,
        Amethyst
    }
}
