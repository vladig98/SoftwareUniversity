﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite
{
    public enum StateEnum
    {
        inProgress,
        Finished
    }
}
