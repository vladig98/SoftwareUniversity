﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories
{
    public enum BakingTechniqueEnum
    {
        crispy,
        chewy,
        homemade
    }
}
