﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories
{
    public enum ToppingTypeEnum
    {
        meat,
        veggies,
        cheese,
        sauce
    }
}
