﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    public enum GenderEnum
    {
        male,
        female
    }
}
