﻿namespace Telephony
{
    public interface IBrowseWeb
    {
        void BrowseWebsite(string website);
    }
}
