﻿namespace Telephony
{
    public interface ICallNumbers
    {
        void CallNumber(string phoneNumber);
    }
}
