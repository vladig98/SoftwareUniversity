﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IBirthDateAble
    {
        string birthDate { get; }
    }
}
