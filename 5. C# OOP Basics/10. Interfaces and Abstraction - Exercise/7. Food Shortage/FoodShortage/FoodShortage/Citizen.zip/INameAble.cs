﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface INameAble
    {
        string name { get; }
    }
}
