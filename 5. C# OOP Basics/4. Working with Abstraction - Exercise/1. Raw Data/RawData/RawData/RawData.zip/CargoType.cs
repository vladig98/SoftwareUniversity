﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
    public enum CargoType
    {
        fragile,
        flamable
    }
}
