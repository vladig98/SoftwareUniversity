﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation
{
    public enum Discount
    {
        VIP = 80,
        SecondVisit = 90,
        None = 0
    }
}
